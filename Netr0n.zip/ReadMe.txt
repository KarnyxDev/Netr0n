============================================
Netr0n by KarnyxDev
===========================================

Description:
---------------------------------------
This virus overwrites the boot partition (MBR), making the computer unbootable.

⚠️ Run only in a virtual machine! ⚠️

This project is created for educational and research purposes only.

🛑 I am not responsible for any damage. 🛑
---------------------------------------